package tries;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Iterator;
import java.util.Scanner;

/**
 * @author jaimevarela
 */
public class Tries {

    /**
     * @param args
     * @throws java.io.FileNotFoundException
     */
    public static void main(String[] args) throws FileNotFoundException {
        //int n = 98906;
        int n = 90000;
        
        char[] alfabeto = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
        Trie t = new Trie(alfabeto);
        Scanner sc = new Scanner(new File("palabras.txt"));
        long inicio = System.nanoTime();
        
        int k=0;
        while(sc.hasNextLine()&&k<n){
            t.insertar(sc.nextLine().toLowerCase());
            k++;
        }
        Iterator it = t.ordenLexicográfico();
        long fin = System.nanoTime();
        System.out.println("Tiempo trie: "+(float)(fin-inicio)/1000000000);

        
        String[] paraMerge = new String[n];
        sc = new Scanner(new File("palabras.txt"));
        inicio = System.nanoTime();
        
        for(int i=0;i<n;i++){
            paraMerge[i] = sc.nextLine().toLowerCase();
        }
        Sort.mergesort(paraMerge);
        fin = System.nanoTime();
        System.out.println("Tiempo merge: "+(float)(fin-inicio)/1000000000);
    }

}
