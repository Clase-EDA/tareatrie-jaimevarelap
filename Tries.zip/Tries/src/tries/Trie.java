package tries;

import java.util.ArrayList;
import static java.util.Arrays.sort;
import java.util.Iterator;

public class Trie {
    public NodoTrie raiz;
    public char[] simbolos;
    
    public Trie(char[] sim){
        sort(sim);
        simbolos = sim.clone();
        raiz = new NodoTrie(simbolos);
    }
    
    public int apuntaA(char c){
        int i =0;
        while(i<simbolos.length&&c!=simbolos[i]){
            i++;
        }
        if(i==simbolos.length){
            throw new RuntimeException("Símbolo inexistente");
        }
        return i;
    }
    
    public boolean buscar(String llave){
        return(buscar(llave,raiz));
    }
    
    public boolean buscar(String llave,NodoTrie actual){
        if(actual == null){
            return false;
        }
        if("".equals(llave)){
            return actual.esFin;
        }
        return buscar(llave.substring(1),actual.hijos[apuntaA(llave.charAt(0))]);
    }
    
    public void insertar(String llave){
        insertar(llave,raiz);
    }
    
    private void insertar(String llave,NodoTrie actual){
        if(llave.equals("")){
            actual.esFin = true;
            return;
        }
        int sig = apuntaA(llave.charAt(0));
        if(actual.hijos[sig]==null){
           actual.hijos[sig]= new NodoTrie(simbolos);
        }
        insertar(llave.substring(1),actual.hijos[sig]);
    }
    
    public void borrar(String llave){
        borrar(llave,raiz);
    }
    
    private NodoTrie borrar(String llave, NodoTrie actual){
        if(llave.equals("")){
            if(!actual.isEmpty()){
                actual.esFin = false;
                return actual;
            }
            return null;
        }
        int sig = apuntaA(llave.charAt(0));
        if(actual.hijos[sig]==null){
            return actual;
        }
        actual.hijos[sig] = borrar(llave.substring(1),actual.hijos[sig]);
        return actual;
    }
    
    public Iterator ordenLexicográfico(){
        ArrayList it = new ArrayList();
        ordenLexicográfico("",raiz,it);
        return it.iterator();
    }

    private void ordenLexicográfico(String llave, NodoTrie actual,ArrayList it) {
        if(actual.esFin){
             it.add(llave);
        }
        for(int i=0;i<simbolos.length;i++){
            if(actual.hijos[i]!=null){
                ordenLexicográfico(llave+simbolos[i],actual.hijos[i],it);
            }
        }
    }
}
