package tries;

/**
 * @author jaimevarela
 */
public class Sort {
    
    private static void merge(Comparable[] arrIzq,Comparable[] arrDer, Comparable[] numeros){
        int n=arrIzq.length;
        int m=arrDer.length;
        int i=0,izq=0,der=0;
        while(izq<n && der<m){
            if(arrIzq[izq].compareTo(arrDer[der])<0){
              numeros[i++] = arrIzq[izq++];
            }
            else{
                numeros[i++] = arrDer[der++];
            }
        }
        while(izq<n){
            numeros[i++] = arrIzq[izq++];
        }
        while(der<m){
            numeros[i++] = arrDer[der++];
        }
    }
    
    public static Comparable[] mergesort(Comparable[] arreglo){
        Comparable[] aux = arreglo;
        mergeSort(aux);
        return aux;
    }

    private static void mergeSort(Comparable[] numeros){
        int n=numeros.length;
        if (n < 2) return;
        int mitad = n/2;
        Comparable[] izq = new Comparable[mitad];
        Comparable[] der = new Comparable[n-mitad];

        int k = 0;
        for(int i = 0;i<n;++i){
            if(i<mitad){
                izq[i] = numeros[i];
            }
            else{
                der[k] = numeros[i];
                k = k+1;
            }
        }
        mergeSort(izq);
        mergeSort(der);
        merge(izq,der,numeros);
    }

}
