package tries;

/**
 *
 * @author jaimevarela
 */
public class NodoTrie {
    public NodoTrie[] hijos;
    public boolean esFin;
    public char[] simbolos;
    
    public NodoTrie(char[] simbolos){
        this.hijos = new NodoTrie[simbolos.length];
        this.simbolos = simbolos;
        this.esFin = false;
        for(int i=0;i<simbolos.length;i++){
            this.hijos[i]=null;
        }
    }
    
    public boolean isEmpty(){
        int i=0;
        while(i<simbolos.length){
            if(this.hijos[i]!=null){
                return false;
            }
            i++;
        }
        return true;
    }
}
